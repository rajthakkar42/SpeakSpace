document.addEventListener('DOMContentLoaded', function() {
  // Mobile Navigation Toggle

  // Access the JSON data passed from the template

    // Get the JSON data from the script tag
    const groupData = JSON.parse(document.getElementById('group-data').textContent);
console.log(groupData);

  const hamburger = document.querySelector('.hamburger');  
  const navLinks = document.querySelector('.nav-links');
  const navItems = document.querySelectorAll('.nav-links a');
  
  hamburger.addEventListener('click', function() {
      navLinks.classList.toggle('active');
      this.classList.toggle('open');
  });

  // Close mobile menu when clicking a nav item
  navItems.forEach(item => {
      item.addEventListener('click', () => {
          navLinks.classList.remove('active');
          hamburger.classList.remove('open');
      });
  });

  // Notification Bell Animation
  const notification = document.querySelector('.notification');
  notification.addEventListener('click', function() {
      this.classList.add('ring');
      setTimeout(() => {
          this.classList.remove('ring');
          // In a real app, this would show notifications
          showNotificationModal();
      }, 1000);
  });

  // Action Card Interactions
  const actionCards = document.querySelectorAll('.action-card');
  actionCards.forEach(card => {
      card.addEventListener('click', function() {
          // Add click effect
          this.classList.add('clicked');
          setTimeout(() => {
              this.classList.remove('clicked');
          }, 300);
          
          // Get action type
          const action = this.querySelector('h3').textContent;
          handleActionClick(action);
      });
  });

  // Stats Card Hover Effects
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach(card => {
      card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-8px)';
      });
      
      card.addEventListener('mouseleave', function() {
          this.style.transform = 'translateY(0)';
      });
  });

  // Initialize Performance Chart (simulated)
  initPerformanceChart();

  function initPerformanceChart() {
    const ctx = document.getElementById('performanceGraph').getContext('2d');
    
    // Generate sample performance data (last 8 weeks)
    const weeks = [];
    const ratings = [];
    const participation = [];
    
    // Base values
    let currentRating = 3.5;
    let currentParticipation = 60;
    
    for (let i = 7; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - (i * 7));
        weeks.push(`Week ${i+1}`);
        
        // Add some randomness to simulate progress
        currentRating += (Math.random() * 0.4) - 0.1;
        currentRating = Math.min(5, Math.max(3, currentRating));
        ratings.push(currentRating);
        
        currentParticipation += (Math.random() * 10) - 3;
        currentParticipation = Math.min(100, Math.max(40, currentParticipation));
        participation.push(currentParticipation);
    }
    
    // Calculate improvement percentage
    const improvement = ((ratings[ratings.length-1] - ratings[0]) / ratings[0]) * 100;
    document.querySelector('.stat-value.up').textContent = `${improvement.toFixed(1)}%`;
    
    // Create the chart
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: weeks,
            datasets: [
                {
                    label: 'Average Rating',
                    data: ratings,
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    borderWidth: 3,
                    tension: 0.3,
                    fill: true,
                    yAxisID: 'y'
                },
                {
                    label: 'Participation %',
                    data: participation,
                    borderColor: '#4cc9f0',
                    backgroundColor: 'rgba(76, 201, 240, 0.1)',
                    borderWidth: 3,
                    tension: 0.3,
                    borderDash: [5, 5],
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 2000,
                easing: 'easeOutQuart'
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Poppins',
                            size: 12
                        },
                        padding: 20,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: {
                        family: 'Poppins',
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        family: 'Poppins',
                        size: 12
                    },
                    padding: 12,
                    usePointStyle: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.datasetIndex === 0) {
                                label += context.raw.toFixed(1) + '/5';
                            } else {
                                label += context.raw.toFixed(0) + '%';
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            family: 'Poppins',
                            size: 12
                        }
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    min: 3,
                    max: 5,
                    ticks: {
                        stepSize: 0.5,
                        callback: function(value) {
                            return value + '/5';
                        },
                        font: {
                            family: 'Poppins',
                            size: 12
                        }
                    },
                    grid: {
                        drawOnChartArea: false
                    },
                    title: {
                        display: true,
                        text: 'Average Rating',
                        font: {
                            family: 'Poppins',
                            size: 12,
                            weight: 'bold'
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 40,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        },
                        font: {
                            family: 'Poppins',
                            size: 12
                        }
                    },
                    grid: {
                        drawOnChartArea: false
                    },
                    title: {
                        display: true,
                        text: 'Participation',
                        font: {
                            family: 'Poppins',
                            size: 12,
                            weight: 'bold'
                        }
                    }
                }
            },
            elements: {
                point: {
                    radius: 5,
                    hoverRadius: 7,
                    backgroundColor: '#fff',
                    borderWidth: 2
                }
            }
        }
    });

    // Update the current average rating display
    document.querySelector('.stat-value').textContent = ratings[ratings.length-1].toFixed(1);
  }


  // Scroll Animations
  const animateOnScroll = function() {
      const elements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-up, .zoom-in');
      const windowHeight = window.innerHeight;
      
      elements.forEach(element => {
          const elementPosition = element.getBoundingClientRect().top;
          const elementVisible = 150;
          
          if (elementPosition < windowHeight - elementVisible) {
              element.style.opacity = '1';
              element.style.transform = 'translate(0, 0) scale(1)';
          }
      });
  };
  
  window.addEventListener('scroll', animateOnScroll);
  animateOnScroll(); // Run once on load

  // View Feedback Button
  const viewFeedbackBtn = document.querySelector('.small-button');
  if (viewFeedbackBtn) {
      viewFeedbackBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          showFeedbackModal();
      });
  }

  // CTA Button
  const ctaButton = document.querySelector('.cta-button');
  if (ctaButton) {
      ctaButton.addEventListener('click', function() {
          // Pulse animation
          this.classList.add('pulse');
          setTimeout(() => {
              this.classList.remove('pulse');
              window.location.href = "#join-session"; // Would navigate in real app
          }, 500);
      });
  }

  // Functions
  function handleActionClick(action) {
      console.log(`Action clicked: ${action}`);
      // In a real app, this would navigate to different sections
      switch(action) {
          case 'Join GD Session':
              showSessionModal('gd');
              break;
          case 'Join Interview':
              showSessionModal('interview');
              break;
          case 'View Leaderboard':
              // Would navigate to leaderboard
              break;
          case 'View Analysis':
              // Would navigate to analysis
              break;
          case 'Connect Peers':
              // Would navigate to network
              window.location.href = "http://127.0.0.1:8000/viewers/login/viewers_dashboard/chatbox/";
              break;
          case 'Resources':
              // Would navigate to resources
              break;
      }
  }

  function initPerformanceChart() {
    const ctx = document.getElementById('performanceGraph').getContext('2d');
    
    // Sample performance data (6 weeks)
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'];
    const performanceScores = [72, 75, 78, 82, 85, 84]; // Scores out of 100
    
    // Calculate performance metrics
    const currentScore = performanceScores[performanceScores.length - 1];
    const bestScore = Math.max(...performanceScores);
    const improvement = ((currentScore - performanceScores[0]) / performanceScores[0]) * 100;
    
    // Update the summary stats
    document.querySelector('.stat-value').textContent = `${currentScore}%`;
    document.querySelector('.stat-value.up').textContent = `+${improvement.toFixed(0)}%`;
    document.querySelector('.improvement-value').textContent = `${improvement.toFixed(0)}%`;
    document.querySelector('.performance-stats .stat-item:last-child .stat-value').textContent = `${bestScore}%`;
    
    // Create the performance chart
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: weeks,
            datasets: [{
                label: 'Your Performance Score',
                data: performanceScores,
                backgroundColor: 'rgba(67, 97, 238, 0.1)',
                borderColor: '#4361ee',
                borderWidth: 3,
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#fff',
                pointBorderColor: '#4361ee',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Poppins',
                            size: 14
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.85)',
                    titleFont: {
                        family: 'Poppins',
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        family: 'Poppins',
                        size: 12
                    },
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            return `Score: ${context.raw}/100`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            family: 'Poppins',
                            size: 12
                        }
                    }
                },
                y: {
                    min: 60,
                    max: 100,
                    ticks: {
                        font: {
                            family: 'Poppins',
                            size: 12
                        },
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeOutQuart'
            }
        }
    });
}

// Call the function when the page loads
document.addEventListener('DOMContentLoaded', initPerformanceChart);

  function showNotificationModal() {
      // Create modal element
      const modal = document.createElement('div');
      modal.className = 'notification-modal';
      groupData.forEach(group=>{

      });
      const groupData = [
        { title: "Session A", description: "This is session A description" },
        { title: "Session B", description: "This is session B description" }
      ];
      
      let htmlString = `
        <div class="modal-content">
          <h3>Notifications (${groupData.length})</h3>
          <ul>
      `;
      
      groupData.forEach(group => {
        htmlString += `
          <li>
            <i class="fas fa-comment-dots"></i>
            <span>${group.title}: ${group.description}</span>
            <small>2 hours ago</small>
          </li>
        `;
      });
      
      htmlString += `
          </ul>
          <button class="close-notifications">
            <i class="fas fa-times"></i> Close
          </button>
        </div>
      `;
      
    modal.innerHTML = htmlString;      
      
      document.body.appendChild(modal);
      
      // Close button
      const closeBtn = modal.querySelector('.close-notifications');
      closeBtn.addEventListener('click', () => {
          modal.style.opacity = '0';
          setTimeout(() => {
              modal.remove();
          }, 300);
      });
      
      // Show modal with animation
      setTimeout(() => {
          modal.style.opacity = '1';
      }, 10);
  }

  function showSessionModal(type) {
      const modal = document.createElement('div');
      modal.className = 'session-modal';
      
      const title = type === 'gd' ? 'Group Discussion' : 'Interview Practice';
      const icon = type === 'gd' ? 'fas fa-comments' : 'fas fa-user-tie';
      
      modal.innerHTML = `
          <div class="modal-content">
              <div class="modal-icon">
                  <i class="${icon}"></i>
              </div>
              <h3>Join ${title} Session</h3>
              <p>Select a session to join from the available options below:</p>
              
              <div class="session-options">
                  <div class="session-option">
                      <h4>${type === 'gd' ? 'Tech Trends Discussion' : 'Technical Interview'}</h4>
                      <p>${type === 'gd' ? '5 participants' : 'With HR Manager'}</p>
                      <small>Starts in 15 minutes</small>
                      <button onclick="location.href='http://127.0.0.1:8000/viewers/login/viewers_dashboard/chatbox/'" class="join-button">Join Now</button>
                  </div>
                  <div class="session-option">
                      <h4>${type === 'gd' ? 'Case Study Analysis' : 'Behavioral Interview'}</h4>
                      <p>${type === 'gd' ? '8 participants' : 'With Career Coach'}</p>
                      <small>Starts in 1 hour</small>
                      <button onclick="location.href='http://127.0.0.1:8000/viewers/login/viewers_dashboard/chatbox/'" class="join-button">Join Now</button>
                  </div>
              </div>
              
              <button class="close-modal">
                  <i class="fas fa-times"></i> Close
              </button>
          </div>
      `;
      
      document.body.appendChild(modal);
      
      // Close button
      const closeBtn = modal.querySelector('.close-modal');
      closeBtn.addEventListener('click', () => {
          modal.style.opacity = '0';
          setTimeout(() => {
              modal.remove();
          }, 300);
      });
      
      // Join buttons
      const joinButtons = modal.querySelectorAll('.join-button');
      joinButtons.forEach(btn => {
          btn.addEventListener('click', function() {
              // In a real app, this would join the session
              alert(`Joining ${this.parentElement.querySelector('h4').textContent}`);
          });
      });
      
      // Show modal with animation
      setTimeout(() => {
          modal.style.opacity = '1';
      }, 10);
  }

  function showFeedbackModal() {
      const modal = document.createElement('div');
      modal.className = 'feedback-modal';
      
      modal.innerHTML = `
          <div class="modal-content">
              <h3><i class="fas fa-comment-alt"></i> Your Feedback</h3>
              <div class="feedback-details">
                  <div class="feedback-section">
                      <h4>Strengths</h4>
                      <ul>
                          <li>Excellent communication skills</li>
                          <li>Strong logical reasoning</li>
                          <li>Good time management</li>
                      </ul>
                  </div>
                  <div class="feedback-section">
                      <h4>Areas to Improve</h4>
                      <ul>
                          <li>Work on more concise responses</li>
                          <li>Practice active listening</li>
                      </ul>
                  </div>
                  <div class="feedback-rating">
                      <h4>Overall Rating: 4.5/5</h4>
                      <div class="stars">
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star"></i>
                          <i class="fas fa-star-half-alt"></i>
                      </div>
                  </div>
              </div>
              <button class="close-modal">
                  <i class="fas fa-times"></i> Close
              </button>
          </div>
      `;
      
      document.body.appendChild(modal);
      
      // Close button
      const closeBtn = modal.querySelector('.close-modal');
      closeBtn.addEventListener('click', () => {
          modal.style.opacity = '0';
          setTimeout(() => {
              modal.remove();
          }, 300);
      });
      
      // Show modal with animation
      setTimeout(() => {
          modal.style.opacity = '1';
      }, 10);
  }
});

// Notification bell animation
const style = document.createElement('style');
style.textContent = `
  @keyframes bellRing {
      0% { transform: rotate(0); }
      10% { transform: rotate(15deg); }
      20% { transform: rotate(-15deg); }
      30% { transform: rotate(15deg); }
      40% { transform: rotate(-15deg); }
      50% { transform: rotate(0); }
      100% { transform: rotate(0); }
  }
  
  .notification.ring {
      animation: bellRing 1s ease;
  }
  
  @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
  }
  
  .cta-button.pulse {
      animation: pulse 0.5s ease;
  }
  
  .action-card.clicked {
      transform: scale(0.98) !important;
      opacity: 0.9 !important;
  }
  
  /* Modal styles */
  .notification-modal,
  .session-modal,
  .feedback-modal {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2000;
      opacity: 0;
      transition: opacity 0.3s ease;
  }
  
  .modal-content {
      background: white;
      border-radius: 16px;
      padding: 2rem;
      max-width: 500px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      position: relative;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
  }
  
  .notification-modal h3,
  .session-modal h3,
  .feedback-modal h3 {
      margin-bottom: 1.5rem;
      color: var(--primary);
      display: flex;
      align-items: center;
      gap: 10px;
  }
  
  .notification-modal ul {
      list-style: none;
  }
  
  .notification-modal li {
      padding: 1rem 0;
      border-bottom: 1px solid #eee;
      display: flex;
      align-items: center;
      gap: 15px;
      position: relative;
  }
  
  .notification-modal li i {
      font-size: 1.2rem;
      color: var(--primary);
  }
  
  .notification-modal li span {
      flex: 1;
  }
  
  .notification-modal li small {
      position: absolute;
      right: 0;
      top: 1rem;
      font-size: 0.7rem;
      color: var(--text-light);
  }
  
  .close-notifications,
  .close-modal {
      background: var(--primary);
      color: white;
      border: none;
      padding: 0.8rem 1.5rem;
      border-radius: 50px;
      margin-top: 1.5rem;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.3s ease;
  }
  
  .close-notifications:hover,
  .close-modal:hover {
      background: var(--secondary);
  }
  
  .session-options {
      margin: 1.5rem 0;
  }
  
  .session-option {
      background: #f9f9f9;
      border-radius: 12px;
      padding: 1.2rem;
      margin-bottom: 1rem;
  }
  
  .session-option h4 {
      margin-bottom: 0.5rem;
      color: var(--text-dark);
  }
  
  .session-option p {
      color: var(--text-light);
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
  }
  
  .session-option small {
      display: block;
      font-size: 0.8rem;
      color: var(--primary);
      margin-bottom: 0.8rem;
  }
  
  .join-button {
      background: var(--primary);
      color: white;
      border: none;
      padding: 0.6rem 1.2rem;
      border-radius: 6px;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.3s ease;
  }
  
  .join-button:hover {
      background: var(--secondary);
  }
  
  .modal-icon {
      width: 60px;
      height: 60px;
      background: rgba(67,97,238,0.1);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1.5rem;
  }
  
  .modal-icon i {
      font-size: 1.8rem;
      color: var(--primary);
  }
  
  .feedback-details {
      margin: 1.5rem 0;
  }
  
  .feedback-section {
      margin-bottom: 1.5rem;
  }
  
  .feedback-section h4 {
      margin-bottom: 0.8rem;
      color: var(--text-dark);
  }
  
  .feedback-section ul {
      padding-left: 1.5rem;
  }
  
  .feedback-section li {
      margin-bottom: 0.5rem;
  }
  
  .feedback-rating {
      text-align: center;
      margin-top: 2rem;
  }
  
  .stars {
      color: #ffc107;
      font-size: 1.5rem;
      margin-top: 0.5rem;
  }
`;
document.head.appendChild(style);