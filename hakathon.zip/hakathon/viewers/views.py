from django.shortcuts import render,redirect
from .models import Users
from modulator.models import AddSessoin

# Create your views here
def landing_page(request):
    return render(request,'landing_page.html')

def login(request):
   if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            if Users.objects.filter(email=email,password=password).exists():
                user = Users.objects.values('id').get(email=email)
                request.session['valid'] = user['id']
                return redirect('viewers_dashboard')
            else:
                print("Login failed")
        except Exception as e:
            print(e)
   return render(request, 'login.html')

def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        user = Users.objects.create(name=name,email=email,phone=phone,password=password)
        user.save()
        return redirect('login')
    return render(request,'signup.html')

def viewers_dashboard(request):
    valid = request.session.get('valid')
    if valid:
        user = Users.objects.get(id=valid)
        groups = AddSessoin.objects.filter(endbyuser='no', session_type='gd').values()
        for group in groups:
            print(group['title'])
        return render(request,'participant.html',{'user':user,'groups':list(groups)})
    else:
        return redirect('login')

def chatbox(request):
    return render(request,'chatbox.html')