from django.urls import path
from . import views

urlpatterns = [
    # Add your URL patterns here
    path('',views.landing_page,name="landing_page"),
    path('login/',views.login,name="login"),
    path('signup/',views.signup,name="signup"), 
    path('login/viewers_dashboard/',views.viewers_dashboard,name="viewers_dashboard"),
    path('login/viewers_dashboard/chatbox/',views.chatbox,name="chatbox"),
] 