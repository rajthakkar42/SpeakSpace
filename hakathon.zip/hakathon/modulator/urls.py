from django.urls import path
from . import views

urlpatterns = [
    # Add your URL patterns here
    # Example:
    # path('', views.index, name='index'),
    path('', views.landing_page, name="landing_page"),
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('login/moderate_dashboard/', views.moderate_dashboard, name="moderate_dashboard"),
    path('login/moderate_dashboard/create_session/', views.create_session, name="create_session"),
    path('login/moderate_dashboard/ask_questions/', views.ask_questions, name="ask_questions"),
   path('login/moderate_dashboard/chatbox/', views.chatbox, name="chatbox"),
] 