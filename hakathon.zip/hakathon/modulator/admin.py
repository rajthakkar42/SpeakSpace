from django.contrib import admin
from .models import Admin, AddSessoin, Message
# Register your models here.
class SIGNUPAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'password', 'phone', 'profile_img']

class AddSessoinAdmin(admin.ModelAdmin):
    list_display = ['id', 'admin_id', 'session_type', 'title', 'topic', 'description', 'created_at', 'destroy_at']


admin.site.register(Admin, SIGNUPAdmin)
admin.site.register(AddSessoin, AddSessoinAdmin)