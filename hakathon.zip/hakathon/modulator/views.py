
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import AddSessoin, Message, Admin
import json
from django.utils import timezone
from django.shortcuts import render, redirect
from datetime import datetime       
# Create your views here.
def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            if Admin.objects.filter(email=email,password=password).exists():
                user = Admin.objects.values('id').get(email=email)
                request.session['valid'] = user['id']
                return redirect('moderate_dashboard')
            else:
                print("Login failed")
        except Exception as e:
            print(e)
    return render(request, 'login.html')
def signup(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        try:
            if Admin.objects.filter(email=email).exists():
                return redirect('login')
            else:
                 Admin.objects.create(name=name,email=email,password=password,phone=phone,)
                 return redirect('login')
        except Exception as e:
            print(e)
    return render(request,'signup.html')

def landing_page(request):
    return render(request,'landing_page.html')

def moderate_dashboard(request):
    valid = request.session.get('valid')
    if valid:
        count = AddSessoin.objects.filter(admin_id=valid).count()
       
        # Ongoing: started already and not yet destroyed
        ongoing_events = AddSessoin.objects.filter(
            created_at__lte=timezone.now(),
            destroy_at__gte=timezone.now(),
            endbyuser="no"
        )
        active_count = ongoing_events.count()
        # Upcoming: start time is in the future 
        upcoming_events = AddSessoin.objects.filter(created_at__gt=timezone.now())
        
        return render(request, 'moderate_dashboard.html', {
            'ongoing_events': ongoing_events,
            'upcoming_events': upcoming_events,
            'count':count,
            'active_count':active_count,
            
        })
    else:
        return redirect('login')


def create_session(request):
    valid = request.session.get('valid')
    
    if not valid:
        return redirect('login')

    if request.method == 'POST':
        title = request.POST.get('title')
        topic = request.POST.get('topic')
        description = request.POST.get('description')
        date = request.POST.get('date')
        time = request.POST.get('time')
        radio = request.POST.get('radio')

        if not all([title, topic, description, date, time, radio]):
            # Optional: handle missing input
            return render(request, 'create_session.html', {
                'error': 'Please fill all required fields.'
            })

        try:
            
            expire_datetime = datetime.strptime(f"{date} {time}", '%Y-%m-%d %H:%M')
            
            AddSessoin.objects.create(
                    admin_id=valid,
                    title=title,
                    topic=topic,
                    description=description,
                    created_at=datetime.now(),
                    destroy_at=expire_datetime,
                    session_type=radio,
                )


            # return render(request, 'create_session.html', {
            #     'success': 'Session created successfully!'
            # })
            return redirect('ask_questions')

        except Admin.DoesNotExist:
            return redirect('login')  # If admin not found, force re-login

        except ValueError:
            return render(request, 'create_session.html', {
                'error': 'Invalid date/time format.'
            })
    
    return render(request, 'create_session.html')


def ask_questions(request):
    return render(request,'ask_questions.html')

def chatbox(request):
    return render(request,'chatbox.html')
