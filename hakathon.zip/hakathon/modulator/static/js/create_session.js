
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarLinks = document.querySelector('.navbar-links');
    
    if (navbarToggler && navbarLinks) {
        navbarToggler.addEventListener('click', function() {
            navbarLinks.classList.toggle('active');
            this.querySelector('i').classList.toggle('fa-bars');
            this.querySelector('i').classList.toggle('fa-times');
        });
    }
    
    // Form elements
    const sessionForm = document.getElementById('sessionForm');
    const sessionTitle = document.getElementById('sessionTitle');
    const sessionTypeRadios = document.querySelectorAll('input[name="sessionType"]');
    const sessionTopic = document.getElementById('sessionTopic');
    const sessionDate = document.getElementById('sessionDate');
    const sessionTime = document.getElementById('sessionTime');
    const sessionDuration = document.getElementById('sessionDuration');
    const sessionDescription = document.getElementById('sessionDescription');
    const generateTopicBtn = document.getElementById('generateTopicBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    
    // Preview elements
    const previewTitle = document.getElementById('previewTitle');
    const previewType = document.getElementById('previewType');
    const previewTopic = document.getElementById('previewTopic');
    const previewDateTime = document.getElementById('previewDateTime');
    const previewDuration = document.getElementById('previewDuration');
    const previewParticipants = document.getElementById('previewParticipants');
    
    // Participants elements
    const participantSearch = document.getElementById('participantSearch');
    const addParticipantBtn = document.querySelector('.btn-add-participant');
    const participantOptions = document.querySelectorAll('.participant-option input[type="checkbox"]');
    const selectedParticipantsContainer = document.querySelector('.selected-participants');
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    sessionDate.min = today;
    
    // Set default time to next hour
    const now = new Date();
    const nextHour = new Date(now.setHours(now.getHours() + 1, 0, 0, 0));
    sessionTime.value = nextHour.toTimeString().substring(0, 5);
    
    // Update preview in real-time
    function updatePreview() {
        // Title
        previewTitle.textContent = sessionTitle.value || 'New Session';
        
        // Type
        const selectedType = document.querySelector('input[name="sessionType"]:checked').value;
        previewType.textContent = selectedType === 'gd' ? 'Group Discussion' : 'Interview';
        
        // Topic
        previewTopic.textContent = sessionTopic.value || 'Topic will appear here';
        
        // Date & Time
        if (sessionDate.value && sessionTime.value) {
            const dateObj = new Date(`${sessionDate.value}T${sessionTime.value}`);
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            previewDateTime.textContent = dateObj.toLocaleDateString('en-US', options);
        } else {
            previewDateTime.textContent = 'Date & time';
        }
        
        // Duration
        previewDuration.textContent = `${sessionDuration.value} minutes`;
    }
    
    // Event listeners for form inputs
    sessionTitle.addEventListener('input', updatePreview);
    sessionTopic.addEventListener('input', updatePreview);
    sessionDate.addEventListener('change', updatePreview);
    sessionTime.addEventListener('change', updatePreview);
    sessionDuration.addEventListener('change', updatePreview);
    
    sessionTypeRadios.forEach(radio => {
        radio.addEventListener('change', updatePreview);
    });
    
    // Generate topic with AI (mock functionality)
    generateTopicBtn.addEventListener('click', function() {
        showToast('Generating topic suggestions...', 'info');
        
        // Mock AI generation with timeout
        setTimeout(() => {
            const aiTopics = [
                "The impact of artificial intelligence on modern workplaces",
                "Sustainable business practices in the tech industry",
                "Remote work: Pros, cons, and future trends",
                "Ethical considerations in data privacy",
                "The future of renewable energy technologies"
            ];
            
            const randomTopic = aiTopics[Math.floor(Math.random() * aiTopics.length)];
            sessionTopic.value = randomTopic;
            updatePreview();
            
            showToast('Topic generated successfully!', 'success');
        }, 1500);
    });
    
    // Cancel button
    cancelBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to cancel? All unsaved changes will be lost.')) {
            window.location.href = 'moderator_dashboard.html';
        }
    });
    
    // Form submission
    sessionForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!sessionTitle.value.trim()) {
            showToast('Please enter a session title', 'error');
            sessionTitle.focus();
            return;
        }
        
        if (!sessionTopic.value.trim()) {
            showToast('Please enter a session topic', 'error');
            sessionTopic.focus();
            return;
        }
        
        // Get selected participants
        const selectedParticipants = Array.from(document.querySelectorAll('.participant-option input[type="checkbox"]:checked'))
            .map(checkbox => checkbox.value);
            
        if (selectedParticipants.length === 0) {
            showToast('Please select at least one participant', 'error');
            return;
        }
        
        // Show success message
        showToast('Session created successfully!', 'success');
        
        // Reset form (in a real app, you would redirect or do something else)
        setTimeout(() => {
            sessionForm.reset();
            selectedParticipantsContainer.innerHTML = '';
            updatePreview();
        }, 2000);
    });
    
    // Participants functionality
    participantOptions.forEach(option => {
        option.addEventListener('change', function() {
            updateSelectedParticipants();
        });
    });
    
    function updateSelectedParticipants() {
        // Clear existing chips
        selectedParticipantsContainer.innerHTML = '';
        
        // Get selected participants
        const selectedParticipants = Array.from(document.querySelectorAll('.participant-option input[type="checkbox"]:checked'));
        
        if (selectedParticipants.length === 0) {
            selectedParticipantsContainer.innerHTML = '<span class="no-participants">No participants selected</span>';
            previewParticipants.textContent = 'No participants selected';
            return;
        }
        
        // Create chips for selected participants
        selectedParticipants.forEach(checkbox => {
            const participantOption = checkbox.closest('.participant-option');
            const name = participantOption.querySelector('.participant-name').textContent;
            const email = participantOption.querySelector('.participant-email').textContent;
            const imgSrc = participantOption.querySelector('img').src;
            
            const chip = document.createElement('div');
            chip.className = 'participant-chip';
            chip.innerHTML = `
                <img src="${imgSrc}" alt="${name}">
                <span>${name}</span>
                <span class="remove-chip" data-id="${checkbox.value}">&times;</span>
            `;
            
            selectedParticipantsContainer.appendChild(chip);
        });
        
        // Update preview
        previewParticipants.textContent = `${selectedParticipants.length} participant${selectedParticipants.length > 1 ? 's' : ''} selected`;
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-chip').forEach(button => {
            button.addEventListener('click', function() {
                const participantId = this.getAttribute('data-id');
                const checkbox = document.querySelector(`.participant-option input[type="checkbox"][value="${participantId}"]`);
                if (checkbox) {
                    checkbox.checked = false;
                    updateSelectedParticipants();
                }
            });
        });
    }
    
    // Search participants
    participantSearch.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        document.querySelectorAll('.participant-option').forEach(option => {
            const name = option.querySelector('.participant-name').textContent.toLowerCase();
            const email = option.querySelector('.participant-email').textContent.toLowerCase();
            
            if (name.includes(searchTerm) || email.includes(searchTerm)) {
                option.style.display = 'block';
            } else {
                option.style.display = 'none';
            }
        });
    });
    
    // Add participant button
    addParticipantBtn.addEventListener('click', function() {
        const email = participantSearch.value.trim();
        
        if (!email) {
            showToast('Please enter an email address', 'error');
            return;
        }
        
        if (!validateEmail(email)) {
            showToast('Please enter a valid email address', 'error');
            return;
        }
        
        // In a real app, you would check if the participant exists or add them to the system
        showToast(`Invitation sent to ${email}`, 'success');
        participantSearch.value = '';
    });
    
    // Toast notification function
    function showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = 'toast';
        
        // Add type class
        if (type === 'success' || type === 'error') {
            toast.classList.add(type);
        }
        
        // Add icon based on type
        let icon = '';
        switch(type) {
            case 'success':
                icon = 'fas fa-check-circle';
                break;
            case 'error':
                icon = 'fas fa-exclamation-circle';
                break;
            case 'info':
            default:
                icon = 'fas fa-info-circle';
        }
        
        toast.innerHTML = `<i class="${icon}"></i> ${message}`;
        
        // Show toast
        toast.classList.add('show');
        
        // Hide after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
    
    // Email validation helper
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    // Initialize preview
    updatePreview();
    
    // Initialize participants display
    updateSelectedParticipants();
});