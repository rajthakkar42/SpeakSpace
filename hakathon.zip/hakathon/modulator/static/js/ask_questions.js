document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const departmentSelect = document.getElementById('department');
    const loadFromCSVBtn = document.getElementById('loadFromCSV');
    const addManuallyBtn = document.getElementById('addManually');
    const csvSection = document.getElementById('csvSection');
    const manualSection = document.getElementById('manualSection');
    const csvFileInput = document.getElementById('csvFile');
    const dropZone = document.getElementById('dropZone');
    const manualQuestions = document.getElementById('manualQuestions');
    const questionsPreview = document.getElementById('questionsPreview');
    const questionCount = document.getElementById('questionCount');
    const createSessionBtn = document.getElementById('createSessionBtn');
    const downloadSample = document.getElementById('downloadSample');
    const modalOverlay = document.getElementById('modalOverlay');
    const closeModal = document.getElementById('closeModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    const viewSessionBtn = document.getElementById('viewSessionBtn');
    const modalQuestionCount = document.getElementById('modalQuestionCount');
    const modalDept = document.getElementById('modalDept');
    const modalSessionId = document.getElementById('modalSessionId');
    const numQuestionsRange = document.getElementById('numQuestionsRange');
    const numQuestionsValue = document.getElementById('numQuestionsValue');
    const numQuestionsSelector = document.getElementById('numQuestionsSelector');
    
    // Current session data
    let currentSession = {
        department: '',
        questions: [],
        source: 'csv', // or 'manual'
        allCSVQuestions: [] // Store all questions from CSV
    };
    
    // Initialize the page
    function init() {
        setupEventListeners();
        animateElements();
    }
    
    // Set up all event listeners
    function setupEventListeners() {
        departmentSelect.addEventListener('change', handleDepartmentChange);
        loadFromCSVBtn.addEventListener('click', () => toggleQuestionSource('csv'));
        addManuallyBtn.addEventListener('click', () => toggleQuestionSource('manual'));
        csvFileInput.addEventListener('change', handleFileUpload);
        dropZone.addEventListener('dragover', handleDragOver);
        dropZone.addEventListener('dragleave', handleDragLeave);
        dropZone.addEventListener('drop', handleDrop);
        manualQuestions.addEventListener('input', handleManualInput);
        createSessionBtn.addEventListener('click', createSession);
        downloadSample.addEventListener('click', downloadSampleCSV);
        closeModal.addEventListener('click', closeModalWindow);
        closeModalBtn.addEventListener('click', closeModalWindow);
        viewSessionBtn.addEventListener('click', viewSession);
        numQuestionsRange.addEventListener('input', handleNumQuestionsChange);
    }
    
    // Animate elements on page load
    function animateElements() {
        const creationCard = document.querySelector('.creation-card');
        creationCard.style.opacity = '1';
        creationCard.style.transform = 'translateY(0)';
        
        document.querySelectorAll('.form-group').forEach((group, index) => {
            group.style.animationDelay = `${index * 0.1}s`;
        });
    }
    
    // Handle department selection change
    function handleDepartmentChange(e) {
        currentSession.department = e.target.value;
    }
    
    // Toggle between CSV and manual question sources
    function toggleQuestionSource(source) {
        currentSession.source = source;
        
        if (source === 'csv') {
            loadFromCSVBtn.classList.add('active');
            addManuallyBtn.classList.remove('active');
            csvSection.classList.remove('hidden');
            manualSection.classList.add('hidden');
            
            if (currentSession.allCSVQuestions.length > 0) {
                numQuestionsSelector.classList.remove('hidden');
                updateRandomQuestions();
            }
        } else {
            loadFromCSVBtn.classList.remove('active');
            addManuallyBtn.classList.add('active');
            csvSection.classList.add('hidden');
            manualSection.classList.remove('hidden');
            numQuestionsSelector.classList.add('hidden');
            handleManualInput({ target: manualQuestions });
        }
    }
    
    // Handle file upload via input
    function handleFileUpload(e) {
        const file = e.target.files[0];
        if (file) processCSVFile(file);
    }
    
    // Handle drag over event
    function handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = '#4361ee';
        dropZone.style.backgroundColor = 'rgba(67, 97, 238, 0.05)';
    }
    
    // Handle drag leave event
    function handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = '#ddd';
        dropZone.style.backgroundColor = 'transparent';
    }
    
    // Handle drop event
    function handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        handleDragLeave(e);
        
        const file = e.dataTransfer.files[0];
        if (file && file.name.endsWith('.csv')) {
            csvFileInput.files = e.dataTransfer.files;
            processCSVFile(file);
        } else {
            alert('Please upload a valid CSV file.');
        }
    }
    
    // Process CSV file and extract questions
    function processCSVFile(file) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const contents = e.target.result;
            const questions = parseCSV(contents);
            
            if (questions.length > 0) {
                currentSession.allCSVQuestions = questions;
                numQuestionsRange.max = questions.length;
                numQuestionsRange.value = Math.min(20, questions.length);
                numQuestionsValue.textContent = numQuestionsRange.value;
                numQuestionsSelector.classList.remove('hidden');
                updateRandomQuestions();
                
                dropZone.innerHTML = `
                    <i class="fas fa-check-circle" style="color: #4bb71b;"></i>
                    <h3>${file.name}</h3>
                    <p>${questions.length} questions loaded successfully</p>
                    <button class="browse-btn">Change File</button>
                `;
            } else {
                alert('No questions found in the CSV file. Please check the format.');
            }
        };
        
        reader.readAsText(file);
    }
    
    // Parse CSV content and extract questions
    function parseCSV(csv) {
        return csv.split('\n')
            .map(line => line.trim().split(',')[0])
            .filter(q => q);
    }
    
    // Handle number of questions range change
    function handleNumQuestionsChange(e) {
        numQuestionsValue.textContent = e.target.value;
        updateRandomQuestions();
    }
    
    // Update random questions selection from CSV
    function updateRandomQuestions() {
        const numQuestions = parseInt(numQuestionsRange.value);
        const allQuestions = [...currentSession.allCSVQuestions];
        const selectedQuestions = [];
        
        for (let i = 0; i < numQuestions && allQuestions.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * allQuestions.length);
            selectedQuestions.push(allQuestions[randomIndex]);
            allQuestions.splice(randomIndex, 1);
        }
        
        currentSession.questions = selectedQuestions;
        updateQuestionsPreview(selectedQuestions);
        console.log("Selected Questions:", currentSession.questions);
    }
    
    // Handle manual questions input
    function handleManualInput(e) {
        const text = e.target.value.trim();
        const questions = text ? text.split(',').map(q => q.trim()).filter(q => q) : [];
        
        currentSession.questions = questions;
        updateQuestionsPreview(questions);
        console.log("Manual Questions:", currentSession.questions);
    }
    
    // Update questions preview section
    function updateQuestionsPreview(questions) {
        questionCount.textContent = `${questions.length} ${questions.length === 1 ? 'question' : 'questions'}`;
        
        if (questions.length > 0) {
            questionsPreview.innerHTML = '';
            questions.forEach((question, index) => {
                const questionElement = document.createElement('div');
                questionElement.className = 'question-item';
                questionElement.innerHTML = `
                    <i class="fas fa-question"></i>
                    <div class="question-text">${index + 1}. ${question}</div>
                `;
                questionsPreview.appendChild(questionElement);
            });
        } else {
            questionsPreview.innerHTML = `
                <div class="empty-state">
                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076478.png" alt="No questions">
                    <p>No questions loaded yet</p>
                </div>
            `;
        }
    }
    
    // Create new session
    function createSession() {
        if (!currentSession.department) {
            alert('Please select a department');
            return;
        }
        
        if (currentSession.questions.length === 0) {
            alert('Please add at least one question');
            return;
        }
        
        console.log('Session Data:', currentSession);
        showSuccessModal();
    }
    
    // Show success modal
    function showSuccessModal() {
        modalQuestionCount.textContent = currentSession.questions.length;
        modalDept.textContent = departmentSelect.options[departmentSelect.selectedIndex].text;
        modalSessionId.textContent = Math.floor(1000 + Math.random() * 9000);
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    // Close modal window
    function closeModalWindow() {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    // View session (would redirect in real app)
    function viewSession() {
        alert('In a complete implementation, this would redirect to the session page.');
        closeModalWindow();
    }
    
    // Download sample CSV
    function downloadSampleCSV(e) {
        e.preventDefault();
        const csvContent = "Question\nWhat are your strengths?\nWhere do you see yourself in 5 years?\nHow do you handle conflict?\nDescribe a challenging situation you faced\nWhat motivates you to work hard?\nHow do you prioritize your work?\nTell me about a time you failed\nWhat are your career goals?";
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', 'sample_questions.csv');
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Initialize the application
    init();
});
console.log(currentSession.questions);