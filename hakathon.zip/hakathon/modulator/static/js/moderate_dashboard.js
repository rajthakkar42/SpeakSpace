// DOM Elements
const sidebar = document.querySelector('.sidebar');
const sidebarToggle = document.querySelector('.sidebar-toggle');
const createSessionBtn = document.querySelector('.btn-primary.pulse-animate');
const modal = document.getElementById('createSessionModal');
const modalClose = document.querySelector('.modal-close');
const modalCloseBtn = document.querySelector('.modal-close-btn');
const sessionForm = document.getElementById('sessionForm');
const sessionTimers = document.querySelectorAll('.session-timer');
const statValues = document.querySelectorAll('.card-value');
const aiGenerateBtn = document.querySelector('.btn-ai');
const toast = document.getElementById('toast');


// Sidebar Toggle
sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('active');
});

// Create Session Modal
createSessionBtn.addEventListener('click', () => {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
});

const closeModal = () => {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
};

modalClose.addEventListener('click', closeModal);
modalCloseBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
modal.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// Form Submission
sessionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Simulate form submission
    const submitBtn = sessionForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Close modal
        closeModal();
        
        // Show success toast
        showToast('Session created successfully!', 'success');
        
        // Reset form
        sessionForm.reset();
    }, 2000);
});

// Update Session Timers
function updateTimers() {
    const now = new Date();
    
    sessionTimers.forEach(timer => {
        const endTime = new Date(timer.getAttribute('data-end'));
        const diff = endTime - now;
        
        if (diff <= 0) {
            timer.textContent = '00:00:00';
            return;
        }
        
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        
        timer.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    });
}

// Animate Stats Counting
function animateStats() {
    statValues.forEach(stat => {
        const target = +stat.getAttribute('data-count');
        const isDecimal = target % 1 !== 0;
        const count = +stat.innerText;
        const increment = target / (isDecimal ? 50 : 20);
        
        if (count < target) {
            stat.innerText = isDecimal 
                ? (count + increment).toFixed(1)
                : Math.ceil(count + increment);
            setTimeout(animateStats, 50);
        } else {
            stat.innerText = isDecimal ? target.toFixed(1) : target;
        }
    });
}

// AI Generate Topic Button
if (aiGenerateBtn) {
    aiGenerateBtn.addEventListener('click', () => {
        // Simulate AI topic generation
        const topics = [
            "The impact of social media on modern communication",
            "Remote work: Benefits and challenges",
            "Ethical implications of artificial intelligence",
            "Sustainable development in urban areas",
            "The future of cryptocurrency in global markets",
            "Work-life balance in the digital age",
            "The role of education in economic development",
            "Climate change: Global responsibility vs individual action",
            "The future of renewable energy technologies",
            "Mental health awareness in workplace environments"
        ];
        
        const randomTopic = topics[Math.floor(Math.random() * topics.length)];
        document.getElementById('sessionTopic').value = randomTopic;
        
        // Show toast notification
        showToast('AI generated a topic suggestion!', 'success');
    });
}

// Show Toast Notification
function showToast(message, type = 'success') {
    toast.textContent = message;
    toast.className = 'toast show';
    toast.classList.add(type);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.className = 'toast';
        }, 300);
    }, 3000);
}

// Initialize animations when page loads
document.addEventListener('DOMContentLoaded', () => {
    // Animate stats counting
    setTimeout(animateStats, 500);
    
    // Update timers every second
    updateTimers();
    setInterval(updateTimers, 1000);
    
    // Animate elements on scroll
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.stat-card, .session-card');
        const windowHeight = window.innerHeight;
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementPosition < windowHeight - elementVisible) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    };
    
    // Initial check
    animateOnScroll();
    
    // Check on scroll
    window.addEventListener('scroll', animateOnScroll);
});

// Add hover effect to all buttons
document.querySelectorAll('button').forEach(button => {
    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-2px)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
    });
});

// Add ripple effect to buttons
document.querySelectorAll('.btn-primary, .btn-secondary, .btn-action').forEach(button => {
    button.addEventListener('click', function(e) {
        const x = e.clientX - e.target.getBoundingClientRect().left;
        const y = e.clientY - e.target.getBoundingClientRect().top;
        
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        
        this.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 1000);
    });
});