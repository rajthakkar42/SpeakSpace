// Smooth scroll to sections on "Get Started" and nav clicks
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

document.getElementById('getStarted').addEventListener('click', function () {
  document.getElementById('features').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

// Animation trigger on scroll
document.addEventListener('scroll', () => {
  const elements = document.querySelectorAll('[data-animate]');
  elements.forEach((element) => {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight;
    if (rect.top >= 0 && rect.top < windowHeight * 0.75) {
      element.style.animation = `${element.dataset.animate} 1s ease forwards`;
      element.style.opacity = '1';
    }
  });
});

// Hover effects with transitions
const interactiveElements = document.querySelectorAll('a, button, .dashboard-card, .hero h1, .hero p, .section-title, .feature-item');
interactiveElements.forEach((element) => {
  element.addEventListener('mouseenter', () => {
    element.style.transition = 'all 0.4s ease-in-out';
  });
  element.addEventListener('mouseleave', () => {
    element.style.transition = 'all 0.4s ease-out';
  });
});

// Preload animations on load
document.addEventListener('DOMContentLoaded', () => {
  const initialElements = document.querySelectorAll('[data-animate]');
  initialElements.forEach((element, index) => {
    setTimeout(() => {
      element.style.animation = `${element.dataset.animate} 1s ease forwards`;
      element.style.opacity = '1';
    }, index * 200);
  });
});

// Dynamic header effect
window.addEventListener('scroll', () => {
  const header = document.querySelector('header');
  if (window.scrollY > 50) {
    header.style.backgroundColor = '#e0e6ed';
    header.style.padding = '10px 0';
    header.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.3)';
  } else {
    header.style.backgroundColor = '#ffffff';
    header.style.padding = '15px 0';
    header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
  }
});

document.addEventListener('DOMContentLoaded', () => {
  // Get all elements with data-animate attribute
  const animatedElements = document.querySelectorAll('[data-animate]');
  
  // Set up the Intersection Observer for scroll animations
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Get the animation type from the data-animate attribute
        const animationType = entry.target.getAttribute('data-animate');
        
        // Add the animation
        entry.target.style.animation = `${animationType} 0.8s forwards`;
        
        // Set initial transforms for specific animations
        if (animationType === 'slideInLeft') {
          entry.target.style.transform = 'translateX(-50px)';
        } else if (animationType === 'slideInRight') {
          entry.target.style.transform = 'translateX(50px)';
        } else if (animationType === 'fadeInDown') {
          entry.target.style.transform = 'translateY(-20px)';
        } else if (animationType === 'fadeInUp') {
          entry.target.style.transform = 'translateY(20px)';
        } else if (animationType === 'zoomIn') {
          entry.target.style.transform = 'scale(0.7)';
        }
        
        // Set opacity to visible
        entry.target.style.opacity = '1';
        
        // Unobserve after animation is triggered
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  // Observe all elements with animations
  animatedElements.forEach(element => {
    observer.observe(element);
  });
  
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const targetElement = document.querySelector(this.getAttribute('href'));
      if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
  
  // Get Started button functionality
  const getStartedBtn = document.getElementById('getStarted');
  if (getStartedBtn) {
    getStartedBtn.addEventListener('click', () => {
      const featuresSection = document.getElementById('features');
      if (featuresSection) {
        featuresSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  }
  
  // Dynamic header effect on scroll
  window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    if (window.scrollY > 50) {
      header.style.backgroundColor = 'var(--primary-light)';
      header.style.padding = '10px 0';
      header.style.boxShadow = 'var(--box-shadow)';
    } else {
      header.style.backgroundColor = 'var(--light-color)';
      header.style.padding = '15px 0';
      header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
    }
  });
});