from django.db import models
from django.utils import timezone
# Create your models here.
class Admin(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=200)
    password = models.CharField(max_length=100)
    phone = models.CharField(max_length=10)
    profile_img = models.CharField(max_length=200,null=True,blank=True)
    def __str__(self):
        return f"{self.id} {self.name} {self.email} {self.password} {self.phone}{self.profile_img}"

class AddSessoin(models.Model):
    id = models.AutoField(primary_key=True)
    admin_id = models.CharField(max_length=30)
    title = models.CharField(max_length=100)
    topic = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    destroy_at = models.DateTimeField(null=True, blank=True)
    session_type = models.CharField(max_length=100, null=True, blank=True)
    endbyuser = models.CharField(max_length=10,default="no")

    def __str__(self):
        return f"{self.id} {self.admin_id} {self.session_type} {self.title} {self.topic} {self.description} {self.created_at} {self.destroy_at}"
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class Message(models.Model):
    # Using AddSession.id as room_id (as you requested)
    room_id = models.IntegerField()  # This stores the AddSession.id as the chat room identifier
    sender = models.ForeignKey(User, on_delete=models.CASCADE)  # Assuming you're using Django's User model
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_voice_note = models.BooleanField(default=False)
    voice_note_url = models.URLField(blank=True, null=True)  # Stores URL to the voice recording

    class Meta:
        ordering = ['timestamp']
        verbose_name = 'Message'
        verbose_name_plural = 'Messages'

    def __str__(self):
        return f"Message in room {self.room_id} by {self.sender.username} at {self.timestamp}"
